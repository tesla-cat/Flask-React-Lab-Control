LMS Win32 SDK - Microsoft STDCALL calling convention
This is version 1.6 of the Lab Brick Microwave Synthesizer dll for 32 bit Windows platforms
Released 6/7/2016

This version of the dll supports the following devices:
LMS-103, LMS-123, LMS-203, LMS-802, LMS-163, LMS-232D
LMS-402D, LMS-602D, LMS-451D, LMS-322D, LMS-271D, LMS-152D
LMS-751D, LMS-252D, LMS-6123LH, LMS-163LH, LMS-802LH
LMS-802DX, LMS-183DX

This dll is suitable for use with Visual Basic for Applications